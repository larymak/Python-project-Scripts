<?php
    $user = 'root';
    $pass = '';
    $db = 'getabook';
    $link = mysqli_connect('localhost', $user, $pass, $db);
?>