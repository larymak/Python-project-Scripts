<!-- Site Icon -->
<link rel="icon" href="Resources/logo.jpg">