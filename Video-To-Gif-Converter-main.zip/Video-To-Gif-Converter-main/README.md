# Video-To-Gif-Converter
a simple program that converts any video to gif
